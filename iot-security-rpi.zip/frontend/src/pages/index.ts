export { Login } from './Login';
export { Register } from './Register';
export { Dashboard } from './Dashboard';
export { Zones } from './Zones';
export { Devices } from './Devices';
export { Events } from './Events';
export { Evidences } from './Evidences';
export { Measurements } from './Measurements';
